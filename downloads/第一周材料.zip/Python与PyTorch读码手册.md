# Python 与 PyTorch 读码手册 —— 从 minimal_gpt 到训练框架

> **配套代码**：第一周发放的 `minimal_gpt/` 文件夹（`minimal_gpt.py` = 推理，`train_toylang.py` = 训练）。
> **用法**：代码开一边、手册开一边。本课的工作方式是"AI 动手，你监督到每一行"——这本手册帮你把每一行看懂。
> **假设**：你会至少一门语言（Mathematica / C++ 皆可，手册两边都给类比），懂线性代数。不假设你学过 Python。
> 遇到手册没覆盖的语法：先问你的 AI 助手，这本身就是练习。

---

## 0. 怎么用这本手册

- **第一遍**（本周）：§1–§9 顺读，每节的例子都能在 `minimal_gpt.py` 里找到原文——标注了行号附近的函数名，对照着读。
- **第二遍**（背诵作业时）：§10 的形状追踪表 = 可视化网站每个箭头的代码版。`python minimal_gpt.py --trace` 打印的就是这些形状。
- **改代码前**（周日 Hackathon）：§11 讲透训练循环——你认领的 ablation 就从改 `train_toylang.py` 开始。
- **速查**：§13。

全书约定：`(B, T, C)` = (batch, 序列长度, 通道数)。minimal_gpt 里 `B=1, T=11, C=48`。

---

## 1. import：把工具搬进来

`minimal_gpt.py` 开头：

```python
import argparse, base64, json, math, random   # 一行导入多个标准库模块
import numpy as np                            # 导入并取别名
import torch, torch.nn as nn, torch.nn.functional as F
```

- `import math` → 之后用 `math.sqrt(x)` 调用；
- `import torch.nn as nn` → 别名，之后写 `nn.Linear` 而不是 `torch.nn.Linear`；
- `from functools import partial`（train 框架里会见到）→ 只把 `partial` 这一个名字搬进来。

**C++ 类比**：`import X` ≈ `#include` + 命名空间限定；`from X import Y` ≈ `using X::Y`。
**Mathematica 类比**：`Needs["X`"]`，但 Python 必须显式写模块名前缀（除非 `from ... import`）。

三个常用惯例记住就行：`np` = NumPy，`nn` = 神经网络模块，`F` = 函数式 API（`F.softmax`、`F.cross_entropy`）。

---

## 2. 容器与语法陷阱

### 2.1 list / tuple / dict

```python
x = [1, 2, 3]          # list：可变（能改元素、能 append）
t = (1, 2, 3)          # tuple：不可变（创建后动不了）
d = {"n_layer": 3}     # dict：键值对；d["n_layer"] 访问，d["k"]=v 添加
```

`minimal_gpt.py` 真实例子：

```python
VOCAB = "ABC"                                  # 字符串也是序列，VOCAB[2] == "C"
encode = lambda s: [VOCAB.index(c) for c in s] # "BAC" -> [1, 0, 2]
cfg = json.load(open(path))["config"]          # cfg 是 dict：cfg["n_head"] == 2
```

| Python | Mathematica | 说明 |
|--------|-------------|------|
| `[a, b, c]` | `{a, b, c}` | list → List |
| `(a, b, c)` | `{a, b, c}` | tuple ≈ 不可变 List |
| `{"a": 1}` | `<\|"a" -> 1\|>` | dict → Association |
| `f(*args)` | `f @@ args` | 展开（见 §3） |

### 2.2 拆包赋值

把容器元素一次拆给多个变量——PyTorch 代码里到处都是：

```python
B, T, C = x.shape          # 张量形状拆成三个数（CausalSelfAttention.forward 第一行）
q, k, v = qkv.split(C, dim=2)   # 一个张量切成三个
A, B, C = 0, 1, 2          # train_toylang.py 开头：三个字母的 id
```

### 2.3 逗号陷阱（Mathematica 用户必读）

Python 的逗号含义**取决于上下文**：

```python
a = 1, 2        # 赋值右侧：逗号创建 tuple，a == (1, 2)
f(1, 2)         # 函数调用内：逗号是参数分隔符（两个参数）
f((1, 2))       # 一个参数（一个 tuple）
x, y = (1, 2)   # 赋值左侧：拆包
```

单元素 tuple 必须写 `(a,)`——`(a)` 只是带括号的 `a`。

Mathematica 的 `Sequence[1,2,3]` 会自动展开；Python 的 tuple **不会**。要展开必须用 `*`（下一节）——所以 `*` 才对应 `Apply`（`@@`），tuple 本身不对应 `Sequence`。

### 2.4 除法

```python
7 / 2    # 3.5   浮点除法（C++ 整数 / 是整除，Python 不是！）
7 // 2   # 3     整除
7 % 2    # 1     取模
```

`minimal_gpt.py`：`hd = C // self.n_head`（每头维度 = 48 // 2 = 24）——写 `/` 会得到 24.0（浮点数），后面当维度用就报错。

---

## 3. 函数参数

### 3.1 位置参数与关键字参数

定义时不区分；**调用**时才区分：

```python
F.softmax(att, dim=-1)          # dim 按名称传（清晰，推荐）
torch.cat([y1, y2], 3)          # 3 按位置传（等价于 dim=3）
```

规则：按位置传的必须在按名称传的前面。

### 3.2 默认值

```python
def generate(model, prompt_ids, steps, trace=False):   # trace 不传就是 False
```

### 3.3 `*` 与 `**`：展开与收集

```python
# 调用时展开
args = (1, 2, 3);  f(*args)             # 等价 f(1, 2, 3)
kw = {"lr": 5e-4}; AdamW(params, **kw)  # 等价 AdamW(params, lr=5e-4)

# 定义时收集
def f(*args, **kwargs): ...
f(1, 2, a=3)    # args == (1, 2)，kwargs == {"a": 3}
```

`train_toylang.py` 真实例子（很妙，值得盯三分钟）：

```python
xs, ys = zip(*[ds[i] for i in range(bs)])
```

分解：`[ds[i] ...]` 生成 64 个 `(x, y)` 对的 list → `*` 把它展开成 64 个参数 → `zip` 把它们"转置"成
（64 个 x）和（64 个 y）两组 → 拆包给 `xs, ys`。这是 Python 版的 `Transpose`。

### 3.4 `partial`：固定一部分参数

```python
from functools import partial
AdamWFactory = partial(torch.optim.AdamW, fused=True)
# 之后 AdamWFactory(params) == torch.optim.AdamW(params, fused=True)
```

数学类比：给定 $f(x,y,z)$，`partial(f, z=3)` 返回 $g(x,y)=f(x,y,3)$。（第二周框架里会见到。）

---

## 4. 类与 nn.Module：`model(x)` 为什么能跑

### 4.1 基本类语法（对照 `minimal_gpt.py` 的 `Block`）

```python
class Block(nn.Module):                       # Block 继承自 nn.Module
    def __init__(self, n_embd, n_head, block_size):
        super().__init__()                    # 先调父类构造函数（nn.Module 需要）
        self.ln_1 = nn.LayerNorm(n_embd)      # self.xxx = 成员变量
        self.attn = CausalSelfAttention(n_embd, n_head, block_size)

    def forward(self, x):                     # 前向计算写在 forward 里
        x = x + self.attn(self.ln_1(x))
        return x
```

- `self`：方法的第一个参数自动接收实例本身（≈ C++ 的 `this`，但必须显式写出来）；
- `super().__init__()`：调用父类构造函数；
- Python 没有 `public/private`，下划线前缀 `_init_weights` 只是"这是内部方法"的**约定**。

### 4.2 三种"加括号调用"

| `x()` 里的 x 是 | 效果 |
|---|---|
| 类 | 创建实例：`GPT(cfg)` 返回一个模型对象 |
| 实例 | 执行 `x.__call__(...)`（没定义就报错） |
| 函数 | 执行函数体 |

**关键机关**：`nn.Module` 定义了 `__call__`，内部转发给 `forward`：

```python
model(idx)        # 实际执行 model.__call__(idx) → 内部调 model.forward(idx)
```

所以 `x = x + self.attn(self.ln_1(x))` 里，`self.ln_1(x)`、`self.attn(...)` 都是"实例当函数用"。
（为什么不直接调 `forward`？`__call__` 里还挂着 PyTorch 的钩子逻辑——永远用 `model(x)`，别用 `model.forward(x)`。）

### 4.3 isinstance：按类型分支

`train_toylang.py` 的权重初始化：

```python
def _init(m):
    if isinstance(m, nn.Linear):        # m 是线性层吗？
        nn.init.normal_(m.weight, mean=0.0, std=0.02)
    elif isinstance(m, nn.Embedding):
        ...
model.apply(_init)                      # 对模型的每个子模块递归调用 _init（见 §9）
```

### 4.4 `@dataclass`（第二周框架的配置写法）

```python
@dataclass
class GPTConfig:
    n_layer: int = 12
    n_embd: int = 768
```

`@dataclass` 是**装饰器**：接收类、返回增强版的类——自动生成 `__init__` 等，等价于手写
`def __init__(self, n_layer=12, n_embd=768): self.n_layer = n_layer; ...`。
注意：`n_layer: int` 的类型注解 **Python 不强制**（写 `config.n_layer = "hi"` 也不报错），只服务于 IDE 提示和文档。
minimal_gpt 用的是更朴素的 dict 配置（`cfg["n_layer"]`），两种风格都要认识。

---

## 5. 张量 I：索引与切片

### 5.1 一维切片（list / tuple / 张量通用）

```python
x[1:4]     # 索引 1,2,3（含头不含尾！）
x[:3]      # 前 3 个
x[-1]      # 最后一个
x[-2:]     # 最后两个
x[::2]     # 步长 2
```

`minimal_gpt.py` 真实例子：

```python
cond = idx[:, -model.block_size:]   # 生成循环里：只保留最后 11 个 token
seq = cat[:-1]; y = cat[1:]         # train：x = 前 11 个，y = 后 11 个（左移一位！）
```

**Mathematica 对照**：`x[a:b]` ≈ `x[[a+1 ;; b]]`——Python 从 0 数、尾端开区间；Mathematica 从 1 数、双端闭区间。`-1` 表示末尾，两边相同。

### 5.2 多维索引（张量特有）

```python
x[:, -1, :]    # 所有 batch 的最后一个位置，形状 (B, T, C) → (B, C)
x[0, 5]        # 第 0 个 batch、第 5 个位置的向量
logits[0, -1]  # minimal_gpt 生成时：取最后一列 logits
```

`:` = "这一维全要"（Mathematica 的 `All`）。注意 list 不支持 `a[:, 1]`——这是 NumPy/PyTorch 的扩展语法。

### 5.3 省略号与 None

```python
x[..., :d]        # "..." 自动补足中间所有 ":"——取最后一维的前 d 个
cos[None, :, None, :]   # None = 在该处插一个大小为 1 的新维度（为广播做准备，见 §6.3）
```

（minimal_gpt 没用到这两个，第二周框架的 RoPE 代码里是主角——见 §12。）

### 5.4 标量索引 vs 列表索引

```python
v[:, -1]      # 形状 (B,)   ：标量索引，这一维消失
v[:, [-1]]    # 形状 (B, 1) ：列表索引，这一维保留（大小 1）
```

Mathematica 对照：`v[[All, -1]]` vs `v[[All, {-1}]]`——完全同一个区别。

### 5.5 布尔索引（第二周采样代码里的 top-k）

```python
logits[logits < v[:, [-1]]] = -float('Inf')
```

三步：`v[:, [-1]]` 取每行阈值（保持 2D 才能广播）→ `logits < 阈值` 得到布尔张量 → 用布尔张量当索引，把 True 的位置统统赋值。一行完成"小于阈值的全部置为 −∞"。

---

## 6. 张量 II：形状变换与广播

### 6.1 张量是"满矩形"

```python
[[1, 2], [3, 4, 5]]               # list 可以参差不齐
torch.tensor([[1, 2], [3, 4, 5]]) # 张量不行，报错——每维大小固定
```

内存里按**行优先**一维排开：`[[1,2,3],[4,5,6]].flatten() == [1,2,3,4,5,6]`。

### 6.2 view / cat

```python
x.view(3, 2)      # 不动内存，只重新分组解读；要求总元素数不变
x.view(B, T, -1)  # -1 = 这一维自动推断

torch.cat([y1, y2], dim)   # 沿 dim 拼接；其余维度必须完全相同
```

`minimal_gpt.py` attention 里的连招（背诵作业的核心形状变换）：

```python
q = q.view(B, T, nh, hd).transpose(1, 2)   # (B,T,C) → (B,T,2,24) → (B,2,T,24)
...
y = y.transpose(1, 2).contiguous().view(B, T, C)   # 逆操作拼回 (B,T,C)
```

`transpose` 交换两个维度但**不动内存**；动过 transpose 的张量内存不再连续，`view` 会拒绝工作——所以要先 `.contiguous()`（真正搬一次内存）再 `view`。这就是那串三连的由来。

### 6.3 广播（broadcasting）

两个形状不同的张量做逐元素运算时，PyTorch 按规则自动扩展：

1. **右对齐**，缺的维度左边补 1：`(T,C)` 和 `(B,T,C)` → `(1,T,C)` 和 `(B,T,C)`；
2. 每个维度要么相同、要么其中一个是 1（是 1 的沿该维复制）；
3. 输出形状取每维的 max。

`minimal_gpt.py` 里最重要的一次广播——Embedding：

```python
tok = self.transformer.wte(idx)                    # (B, T, C)
pos = self.transformer.wpe(torch.arange(T))        # (T, C)
x = tok + pos                                      # (T,C) 广播成 (1,T,C) 再加 → (B,T,C)
```

每个 batch 都加上同一份位置向量——一行代码，零循环。

### 6.4 einsum（可选，但数学系会喜欢）

爱因斯坦求和记号直接搬进代码：

```python
torch.einsum('ij,jk->ik', A, B)   # 矩阵乘法：out[i,k] = Σ_j A[i,j]B[j,k]
torch.einsum('i,j->ij', a, b)     # 外积
torch.einsum('ii->', A)           # 迹
```

规则：同字母 = 同维度；输入有、输出没有的字母 = 对它求和。日常写法还是 `@`（矩阵乘）和 `*`（逐元素），但读别人代码会撞见 einsum。

---

## 7. 内存模型：引用、拷贝、视图（bug 高发区）

### 7.1 赋值不复制

```python
x = v        # x、v 指向同一个对象
x[0] = 999   # v 也变了！
```

**Mathematica 用户特别注意**：Mathematica 的 `y = x` 是复制语义，Python 恰恰相反——赋值只传引用。

### 7.2 三个层级

| 操作 | 效果 |
|---|---|
| `x = v` | 引用：完全同一个对象 |
| `v[:]` / `v.copy()`（list） | 浅拷贝：新容器，**内部元素仍共享** |
| `copy.deepcopy(v)` | 深拷贝：逐层全新 |

`train_toylang.py` 里为什么用 deepcopy：

```python
best = {"sd": copy.deepcopy(model.state_dict()), ...}
```

`state_dict()` 里的张量和模型共享内存——不 deepcopy 的话，训练继续走，"存下来的最优权重"会跟着变掉。

### 7.3 张量切片是视图（比浅拷贝更激进）

```python
b = a[:2]    # b 与 a 共享底层内存
b[0] = 999   # a[0] 也变成 999！
```

list 切片给你新容器；**张量切片什么都不新建**，直接窗口到同一块内存。`view`、`transpose` 同理。
要独立副本：`b = a.clone()`。

| 操作 | list | 张量 |
|---|---|---|
| `x = v` | 引用 | 引用 |
| 切片 | 浅拷贝 | **视图（共享内存）** |
| 独立副本 | `deepcopy` | `.clone()` |
| 运算 `v + 1` | 新对象 | 新张量 |

---

## 8. 惯用法拾遗

对照 `minimal_gpt.py` / `train_toylang.py`，每条都有原文。

**列表推导式**（GPT 的层堆叠）：

```python
h = nn.ModuleList([Block(C, nh, block) for _ in range(cfg["n_layer"])])
# 等价于 for 循环 + append；"_" 表示循环变量用不上
```

**三元表达式**：

```python
split = "test" if h % 4 == 0 else "train"     # train_toylang 的数据划分
```

**assert**：不满足就当场报错，是给读者的"此处必真"声明：

```python
assert list(arr.shape) == v["shape"], f"shape mismatch {k}"
```

**f-string**：字符串里 `{表达式}` 直接求值填入：

```python
print(f"loaded: n_head={cfg['n_head']} params={n:,}")   # ":," = 千分位逗号
```

**argparse**（你已经在用了）：

```python
ap = argparse.ArgumentParser()
ap.add_argument("--input", default="BABCAB")
ap.add_argument("--trace", action="store_true")   # 出现即 True 的开关
args = ap.parse_args()          # 之后 args.input / args.trace
# 这就是 python minimal_gpt.py --input BABCAB --trace 的来历
```

**装饰器与 with**（自动"进入/退出"管理）：

```python
@torch.no_grad()          # minimal_gpt 的 generate 顶上那行
def generate(...): ...
```

推理不需要梯度；这个装饰器 = 整个函数体都包在"关闭梯度追踪"环境里，等价于函数内写
`with torch.no_grad(): ...`。C++ 类比：RAII——构造时开、析构时关，异常也不会漏关。
（`@torch.no_grad()` 带括号：先调用得到一个对象，那个对象才是装饰器。）

**yield / 生成器**（第二周框架的流式生成）：

```python
def generate(...):
    for _ in range(max_tokens):
        ...
        yield token     # 产出一个就交出去，函数在此暂停，下次从这里继续
```

调用方 `for tok in model.generate(...)` 就能边生成边打印（ChatGPT 逐字蹦的机制）。
minimal_gpt 的 generate 是普通函数（攒齐再返回）——对比着看正好理解 yield 解决什么问题。

---

## 9. PyTorch 模块系统

**容器必须用 nn 家族的**（`minimal_gpt.py` 的 GPT 构造函数）：

```python
self.transformer = nn.ModuleDict(dict(
    wte=nn.Embedding(V, C),
    h=nn.ModuleList([Block(...) for _ in range(L)]),
    ln_f=nn.LayerNorm(C),
))
```

用普通 dict/list 装模块，PyTorch 就**看不见**里面的参数——不会训练、不会随模型搬家。访问：`self.transformer.wte`、`self.transformer.h[0]`、`for block in self.transformer.h:`。

**register_buffer**（causal mask 的存放处）：

```python
mask = torch.tril(torch.ones(T, T)).view(1, 1, T, T)   # 下三角矩阵！
self.register_buffer("mask", mask, persistent=False)
```

buffer = 不参与训练、但属于模型的张量（随模型移动设备）；`persistent=False` = 不存进 checkpoint。之后用 `self.mask` 访问。`torch.tril` = 下三角（正是"位置 i 只看 ≤ i"的矩阵形态）。

**apply**：对自己和所有子模块递归调用一个函数（初始化的标准姿势，见 §4.3）。

**parameters / numel**：

```python
sum(p.numel() for p in model.parameters())   # 数参数量：85,728 就是这么来的
```

**.to()**：搬设备/换精度，`x.to("cuda")`、`out.to(x.dtype)`。

**方法链**：很多张量方法返回新张量，可以连写：`F.softmax(logits, -1).argmax()`。

---

## 10. 实战 I：minimal_gpt.py 形状全追踪

背诵作业的自检工具。`--trace` 打印的就是这张表；对着可视化网站，每个箭头都应该能对上一行：

```
输入 idx: (B, T) = (1, 11)                     ← 11 个字母的 id
  ↓ wte 查表 + wpe 查表相加（广播，§6.3）
x: (1, 11, 48)
  ↓ ln_1（逐位置归一）
  ↓ c_attn：(1, 11, 48) → (1, 11, 144)         ← 一个矩阵同时算出 q,k,v
  ↓ split → q, k, v 各 (1, 11, 48)
  ↓ view + transpose（§6.2）→ 各 (1, 2, 11, 24)  ← 切成 2 个头
  ↓ q @ k.transpose(-2,-1) / √24 → att: (1, 2, 11, 11)   ← 那张 (T,T) 表！
  ↓ masked_fill(mask==0, -inf)                 ← 上三角封死：只看过去
  ↓ softmax(dim=-1) → 每行变概率
  ↓ att @ v → (1, 2, 11, 24)                   ← v 的加权平均
  ↓ transpose + contiguous + view → (1, 11, 48) ← 两个头拼回
  ↓ c_proj → (1, 11, 48)，加回 x（residual）
  ↓ ln_2 → mlp：48 → 192 → GELU → 48，加回 x
  （以上 Block 重复 3 次）
  ↓ ln_f → lm_head：(1, 11, 48) → (1, 11, 3)
logits: 11 个位置各一列分数 → softmax → 11 列概率
```

**动手**：跑 `python minimal_gpt.py --trace --eval 0`，逐行对照上表；再改 `--input`，看哪些数变了、哪些没变（提示：位置 i 的输出只依赖 ≤ i——课上讲过的那条规则，可以自己用两个输入验证）。

---

## 11. 实战 II：train_toylang.py 训练循环解剖

训练脚本 = 五个部件。周日的 ablation 无论改哪里，先认清全图：

```python
# ① 数据：语言 G 的句子 → (x, y) 对
seq = gen_sequence(rng)          # 12 个 token 的合法句子
x, y = cat[:-1], cat[1:]         # y = x 左移一位（每个位置预测下一个）

# ② 模型：TrainGPT（与 minimal_gpt.GPT 同构，多了 dropout）
logits = model(x)                # (B, 11, 3)

# ③ 损失：所有位置一起算交叉熵
loss = F.cross_entropy(logits.view(-1, 3), y.view(-1))
#      view(-1, 3)：把 (B,11,3) 摊平成 (B*11, 3)——11 个位置全是考题

# ④ 反向 + 更新（背下这四行，所有 PyTorch 训练都长这样）
opt.zero_grad(set_to_none=True)  # 清空上一步的梯度
loss.backward()                  # 反向传播：算出所有参数的梯度
torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)   # 梯度裁剪（防爆）
opt.step()                       # 沿梯度更新参数

# ⑤ 评估：每 100 步在"没见过的句子"上测（train/test 用哈希分流，见 §8 三元表达式）
```

值得注意的三个细节：

- **优化器分组**（`configure_optimizers`）：矩阵参数用 weight decay、bias/LayerNorm/Embedding 不用——
  参数按名字分成两组，各配不同超参传给 AdamW。这是所有正经训练代码的标配结构。
- **dropout 与 `self.training`**：`F.dropout(x, p, self.training)` 只在训练时生效；
  `model.eval()` / `model.train()` 切换这个开关。评估前忘了 `eval()` 是新手第一大坑。
- **最优 checkpoint**：为什么 `deepcopy(model.state_dict())`——见 §7.2。

**动手（周日的形状）**：把 `n_head=2` 改成 1 或 4 重训一次，和你自己跑出的原版比分语境指标；
或者把 `clip_grad_norm_` 那行注释掉看看会怎样。**只改一处，其余不动**——对照实验的铁律。

---

## 12. 预告：第二周训练框架里会遇到的

第二周发的框架是真·GPT 训练代码。多出来的东西提前挂个号，细讲在课上：

**RoPE（旋转位置编码）**：minimal_gpt 用"查表加法"（wpe）编码位置；现代 GPT 改用"旋转"——
把 q、k 的每对分量按位置角度 θ = t·f 做 2D 旋转，点积 q·k 自动携带相对位置信息。
代码上就是 §5.3 的 `None` 广播 + §6.2 的 cat：

```python
x1, x2 = x[..., :d], x[..., d:]              # 最后一维劈两半
y1, y2 = x1*cos + x2*sin, -x1*sin + x2*cos   # 旋转（cos/sin 预先造表，用 None 对齐形状）
out = torch.cat([y1, y2], -1)
```

**融合的 attention**：那串 手写 softmax(qkᵀ/√A)·v 会被一行替换：

```python
y = F.scaled_dot_product_attention(q, k, v, is_causal=True)   # is_causal = 自动下三角 mask
```

数学一个字没变，只是内核融合（快、省显存）。**动手**：可以先在 minimal_gpt 里替换验证输出逐位一致。

**batch size 的学问**：mini-batch 梯度是全数据梯度的估计，batch 越大估计越准——但存在
**临界批次大小**，超过之后纯属浪费算力（OpenAI, arXiv:1812.06162）。在临界范围内，
最终 loss 基本只看总 token 数，不看你分几步走。这件事第二周你们会亲手验证。

**多卡训练（DDP）一段话**：每张卡一份完整模型、各算各的 batch → backward 后 All-Reduce
把梯度求平均 → 每张卡用同一份平均梯度更新 → 权重永远一致。通信藏在 backward 里逐层进行，
所以多卡近乎线性加速。模型大到单卡装不下时另有分片方案（FSDP），课上用到再讲。

**研究钩子**（本课精神：一切设计皆可问"为什么"）："每个位置都算 loss"只是设计空间中的一种选择。
近年工作在挑战它：Rho-1（arXiv:2404.07965）发现只在"有用的" token 上算 loss 反而更好；
Multi-Token Prediction（arXiv:2404.19737）让每个位置一次预测后面 n 个 token。
——这类问题，就是问题表欢迎的问题。

---

## 13. 速查表

| 代码 | 含义 |
|------|------|
| `x.shape` / `x.size(0)` | 形状 / 第 0 维大小 |
| `B, T, C = x.shape` | 形状拆包 |
| `x.view(B, T, -1)` | 重塑，`-1` 自动推断 |
| `x[:, -1, :]` | 每个 batch 的最后一个位置 |
| `x[..., :d]` | 最后一维的前 d 个 |
| `x[None]` | 最前面加一维（广播用） |
| `torch.cat([a, b], dim=1)` | 沿维度 1 拼接 |
| `a * b` | 逐元素乘（可广播） |
| `a @ b` | 矩阵乘 |
| `F.softmax(x, dim=-1)` | 最后一维归一成概率 |
| `x.argmax(-1)` | 最后一维最大值的下标 |
| `x.transpose(1, 2)` | 交换维度 1、2（视图！） |
| `x.contiguous()` | 让内存重新连续（view 前常需要） |
| `x.clone()` | 真拷贝（切片只是视图） |
| `p.numel()` | 元素个数 |
| `model.eval()` / `model.train()` | 关/开 dropout 等训练态 |
| `with torch.no_grad():` | 块内不记梯度（推理省内存） |

---

*本手册配合课程材料使用；发现错误或讲不清的地方，带到课程群或周日 Hackathon——顺便，那可能就是一个好问题。*
