# 沙盒环境简报（给 coding agent 读）

> 用途：让**任何一个 Claude session** 几秒内理解这套沙盒环境——沙盒模型、怎么启动、进去之后能做什么。
> **两类读者都覆盖**：① 在**宿主**上、需要为项目配 `.devcontainer` 沙盒的 session；② 已在**沙盒容器内**、准备开工的 session。
> 安装/搭建步骤**不在本文件**（涉及 sudo，人类按《环境搭建指引》完成）。

## 1. 沙盒模型（一句话）

rootless Podman 容器 = 权限边界：容器内你是 root、随便折腾；经 user namespace 映射，落到宿主只是无特权普通用户。所以容器里可以放心全开权限——**篱笆是容器**。

## 2. 如果你在宿主上——为项目配沙盒（devcontainer）

在 repo 放 `.devcontainer/devcontainer.json`：

```jsonc
{
  "name": "<项目名>",
  "image": "localhost/agent-base:latest",
  "runArgs": [
    "-v", "/usr/local/Wolfram:/usr/local/Wolfram:ro",
    "-v", "/etc/machine-id:/etc/machine-id:ro",
    "-v", "${localEnv:HOME}/.Wolfram/Licensing/mathpass:/root/.Wolfram/Licensing/mathpass:ro"
  ],
  "mounts": ["source=claude-cfg,target=/root/.claude,type=volume"],
  "containerEnv": { "IS_SANDBOX": "1" },
  "remoteEnv":    { "IS_SANDBOX": "1" },
  "customizations": { "vscode": { "extensions": ["Anthropic.claude-code"] } }
}
```

- **Dev Containers 这条路用微软 VS Code**（Cursor 的同名 fork 与 podman 不兼容）。
- `IS_SANDBOX=1`：官方逃生阀——Claude Code 默认拒绝 root 下全权限，此变量声明"我在沙盒里"。写两处不是冗余：`containerEnv` 改动要 **Rebuild Container** 才生效，`remoteEnv` 改完 **Reload Window** 即生效。
- 登录态在 `claude-cfg` 具名卷：首次登录后，换容器免登。
- 改完配置：命令面板 → **Dev Containers: Rebuild and Reopen in Container**。
- 本机有 NVIDIA GPU 才加 `"--device", "nvidia.com/gpu=all"`；没有就不加（课程算力在服务器）。

## 3. Mathematica 挂载 —— ⚠ 关键坑：必须挂 `/etc/machine-id`

Wolfram 授权按 **MathID** 绑机器，而 **MathID 是从 `/etc/machine-id` 算的**。容器默认有自己的 machine-id → MathID 算出来是**空的** → 报 `Your Wolfram product is not activated`。**把宿主的 `/etc/machine-id` 只读挂进去，MathID 立刻和宿主一致、授权通过。**（网卡 MAC / `--network host` 都不是关键，machine-id 才是。）

三条挂载，全部 `:ro`（容器只能用，改不动宿主的安装与授权）：

```
-v /usr/local/Wolfram:/usr/local/Wolfram:ro
-v /etc/machine-id:/etc/machine-id:ro
-v ~/.Wolfram/Licensing/mathpass:/root/.Wolfram/Licensing/mathpass:ro
```

容器内使用：`export PATH="$PATH:/usr/local/Wolfram/Wolfram/<版本>/Executables"` 后用 `wolframscript`（无头）。

## 4. 如果你在沙盒容器内——能 / 不能做什么

- 你是 root：`apt` / `pip` 随便装；改动仅存在于本容器，**退出全部丢弃 → 要保留的东西写进 `/work`（就是项目目录），git commit 勤一点**。
- 网络默认可用（装包没问题）。本机没有 GPU 也照常干活——课程算力在服务器上。
- 挂载进来的目录没有副本：删了就真没了（除非 git 能救）。别碰 `/work` 之外你不理解的挂载点。

## 5. 给人类的提示（人类向你问环境问题时）

- 装 podman / Node / Mathematica 这类 **sudo 步骤**：让人类照《环境搭建指引》自己做，你负责解释每条命令。
- 容器里 root 却不能 `cd /work`：多半是宿主设了全局 `userns`（查 `~/.config/containers/containers.conf`，删掉；特殊需求按次 `--userns=` 传）。
- Mathematica 报"未激活"：见 §3——十有八九是 `/etc/machine-id` 没挂。
